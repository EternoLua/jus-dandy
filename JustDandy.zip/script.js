/* VARIABLES */
let startButton, help, forward, backward;
let catcher, firsFallingObject, secondFallingObject;
let forwardX = 375, forwardY = 375;
let backwardX = 25, backwardY = 375;
let score = 0;
let screen = 0;
let firstFallingObjectText = ["\n I am \n resilient", "\n I am \n proud", "\n I have \n limitless \n potential", "\n I deserve \n happiness", "\n I am \n worthy", "\n I'm in \n control", "\n I am \n strong", "\n I am \n capable",];
let secondFallingObjectText = ["\n Unworthy", "\n Weak", "\n Inadequate", "\n No One", "\n Terrible", "\n Insignificant",];
let walls, player, floor, goal;
let tilemap;
let tileSize = 17;
let myFont;
let firstFallingObjectImg, secondFallingObjectImg, homeScreenImg,catcherImg;


/* PRELOAD LOADS FILES */
function preload() {
  myFont = loadFont('assets/Roboto-Regular.ttf');
  firstFallingObjectImg = loadImage('assets/pos-pixel.png');
  secondFallingObjectImg = loadImage('assets/neg-pixel.png');
  homeScreenImg = loadImage('assets/home-screen.png');
  catcherImg = loadImage('assets/catcher.png');
  

}

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(400, 400);
  screen = 0;

  // create buttons
  begin = new Sprite(width / 2, 300);
  help = new Sprite(width / 2, 340);
  forward = new Sprite(-300, -300, 40, 40);
  forward.color = color(95, 158, 160);
  backward = new Sprite(-400, -400, 40, 40);
  backward.color = color(95, 158, 160);



}

/* DRAW LOOP REPEATS */
function draw() {

  // create start button
  begin.color.setAlpha(0);
  begin.textColor = ('white')
  begin.textSize = (14);
  begin.stroke = ('white');
  begin.w = 150;
  begin.h = 40;
  begin.text = 'Begin';

  //create help button
  help.color.setAlpha(0);
  help.text = 'Help';
  help.textColor = ('white');
  help.textSize = (14);
  help.stroke = 'white';
  help.w = 150;
  help.h = 40;

  if (screen == 0) {
    showScreen0();
  }
  if (begin.mouse.presses()) {
    showScreen1();
    screen = 1;
  } else if (screen == 1) {
    if (forward.mouse.presses()) {
      showScreen2();
      screen = 2;
    }
  } else if (screen == 2) {
    if (forward.mouse.presses()) {
      showScreen3();
      screen = 3;
    } else if (backward.mouse.presses()) {
      showScreen1();
      screen = 1;
    }
  } else if (screen == 3) {
    if (forward.mouse.presses()) {
      showScreen4();
      screen = 4;
    } else if (backward.mouse.presses()) {
      showScreen2();
      screen = 2;
    }
  } else if (screen == 4) {
    if (forward.mouse.presses()) {
      showScreen5();
      screen = 5;
    } else if (backward.mouse.presses()) {
      showScreen3();
      screen = 3;
    }
  } else if (screen == 5) {
    if (forward.mouse.presses()) {
      showScreen6();
      screen = 6;
    } else if (backward.mouse.presses()) {
      showScreen4();
      screen = 4;
    }
  } else if (screen == 6) {
    if (forward.mouse.presses()) {
      showScreen7();
      screen = 7;
    } else if (backward.mouse.presses()) {
      showScreen5();
      screen = 5;
    }
  } else if (screen == 7) {
    if (forward.mouse.presses()) {
      showScreen8();
      screen = 8;
    } else if (backward.mouse.presses()) {
      showScreen6();
      screen = 6;
    }
  } else if (screen == 8) {
    if (forward.mouse.presses()) {
      showScreen9();
      screen = 9;
    } else if (backward.mouse.presses()) {
      showScreen7();
      screen = 7;
    }
  } else if (screen == 9) {
    if (forward.mouse.presses()) {
      showInstructionsCatcher();
      screen = 30;
    } else if (backward.mouse.presses()) {
      showScreen8();
      screen = 8;
    }
  } else if (screen == 30) {
    if (forward.mouse.presses()) {
      //screen 10 is play screen
      screen = 10;
      playScreenAssets();
    }
  }
  if (screen == 10) {
    background(209, 237, 242);

    fill('white');
    textSize(15);
    text('  Say 20\n  positive\naffirmations', width - 130, 20);

    //If firstFallingObject reaches bottom, move back to random position at top
    if (firstFallingObject.y >= height) {
      firstFallingObject.y = 0;
      firstFallingObject.x = random(50, 350);
      firstFallingObject.vel.y = (2, 4);
      firstFallingObject.text = random(firstFallingObjectText);

      //Mild 
      score = score - 1;
    }

    //If secondFallingObject reaches bottom, move back to random position at top
    if (secondFallingObject.y >= height) {
      secondFallingObject.y = 0;
      secondFallingObject.x = random(50, 350);
      secondFallingObject.vel.y = (2, 4);
      secondFallingObject.text = random(secondFallingObjectText);
    }

    //Move catcher
    if (kb.pressing("left")) {
      catcher.vel.x = -3;
    } else if (kb.pressing("right")) {
      catcher.vel.x = 3;
    } else {
      catcher.vel.x = 0;
    }

    //Stop catcher at edges of screen
    if (catcher.x < 50) {
      catcher.x = 50;
    } else if (catcher.x > 350) {
      catcher.x = 350;
    }

    // If fallingObject collides with catcher, move back to random position at top
    if (firstFallingObject.collides(catcher)) {
      firstFallingObject.y = 0;
      firstFallingObject.x = random(50, 350);
      firstFallingObject.velocity.y = random(2, 4);
      firstFallingObject.direction = "down";
      firstFallingObject.text = random(firstFallingObjectText);
      score = score + 1;
    }

    // If secondFallingObject collides with catcher, move back to random position at top
    if (secondFallingObject.collides(catcher)) {
      secondFallingObject.y = 0;
      secondFallingObject.x = random(50, 350);
      secondFallingObject.velocity.y = random(2, 4);
      secondFallingObject.direction = "down";
      secondFallingObject.text = random(secondFallingObjectText);
      score = score - 1;
    }

    // Draw the score to screen
    fill(44, 75, 90);
    textSize(20);
    text("Score = " + score, 10, 30);

    // Win condition
    if (score > 19) {
      youWin();
      forward.pos = { x: 190, y: 370 };
      if (forward.mouse.presses()) {
        showScreen11();
        screen = 11;
      }
    }
  } else if (screen == 11) {
    if (forward.mouse.presses()) {
      showScreen12();
      screen = 12;
    }
  } else if (screen == 12) {
    if (forward.mouse.presses()) {
      showScreen13();
      screen = 13;
    } else if (backward.mouse.presses()) {
      showScreen11();
      screen = 11;
    }
  } else if (screen == 13) {
    if (forward.mouse.presses()) {
      showScreen14();
      screen = 14;
    } else if (backward.mouse.presses()) {
      showScreen12();
      screen = 12;
    }
  } else if (screen == 14) {
    if (forward.mouse.presses()) {
      showScreen15();
      screen = 15;
    } else if (backward.mouse.presses()) {
      showScreen13();
      screen = 13;
    }
  } else if (screen == 15) {
    if (forward.mouse.presses()) {
      showScreen16();
      screen = 16;
    } else if (backward.mouse.presses()) {
      showScreen14();
      screen = 14;
    }
  } else if (screen == 16) {
    if (forward.mouse.presses()) {
      showScreen17();
      screen = 17;
    } else if (backward.mouse.presses()) {
      showScreen15();
      screen = 15;
    }
  } else if (screen == 17) {
    if (forward.mouse.presses()) {
      showMazeIntsructions();
      screen = 18;
    } else if (backward.mouse.presses()) {
      showScreen16();
      screen = 16;
    }
  }  else if (screen == 18) {
    if (forward.mouse.presses()) {
      background('grey')
      //screen 19 is maze screen
      screen = 19;
      mazeScreenAssets();
    }
  }

  if (screen == 19){
    // move player
    if (kb.pressing("left")) {
      player.velocity.x = -2;
    } else if (kb.pressing("right")) {
      player.velocity.x = 2;
    } else {
      player.velocity.x = 0;
    }
    if (kb.pressing("up")) {
      player.velocity.y = -2;
    } else if (kb.pressing("down")) {
      player.velocity.y = 2;
    } else {
      player.velocity.y = 0;
    }

    // player wins
    if (player.x > 360){
      player.x = 360;
      youWinMaze();
      
      screen = 20;
      if (forward.mouse.presses()) {
        showScreen20();
      }
    }
  } else if (screen == 20){
    if (forward.mouse.presses()) {
      showScreen21();
      screen = 21;
    }
  } else if (screen == 21){
    if (forward.mouse.presses()){
      showScreen22();
      screen = 22;
    }
    
  } else if (screen == 22){
    if (forward.mouse.presses()){
      showScreen23();
      screen = 23;
    } else if (backward.mouse.presses()){
      showScreen21();
      screen = 21;
    }
  } else if (screen == 23) {
    if (forward.mouse.presses()) {
      showScreen24();
      screen = 24;
    } else if (backward.mouse.presses()) {
      showScreen22();
      screen = 22;
    }
  } else if (screen == 24){
    if (forward.mouse.presses()) {
      showScreen25();
      screen = 25;
    } else if (backward.mouse.presses()) {
      showScreen23();
      screen = 23;
    }
  } else if (screen == 25){
    if (forward.mouse.presses()) {
      showScreen26();
      screen = 26;
    } else if (backward.mouse.presses()) {
      showScreen24();
      screen = 24;
    }
  } else if (screen == 26){
    if (forward.mouse.presses()) {
      showScreen27();
      screen = 27;
    } else if (backward.mouse.presses()) {
      showScreen25();
      screen = 25;
    }
  } else if (screen == 27){
    if (forward.mouse.presses()) {
      showScreen28();
      screen = 28;
    }
  }

}

/* FUNCTIONS */
function showScreen0() {
  background(homeScreenImg);
  begin.pos = { x: width / 2, y: 300 };
  help.pos = { x: width / 2, y: 340 };


}

function showScreen1() {
  background('pink');
  begin.pos = { x: -100, y: -400 };
  help.pos = { x: -400, y: -100 };
  forward.pos = { x: forwardX, y: forwardY };
  backward.pos = { x: -100, y: -500 };
}

function showScreen2() {
  background('teal');

  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(14);
  text('  The sight of all these successful, innovative people, I\n     can’t bear the though of what I am compared to\nthem. An insignificant thing, I am. Painfully aware of this,\n         I sigh. Disappointment, a mild term, far too kind\n                           to describe myself.',40,305);

  // backward button
  backward.pos = { x: backwardX, y: backwardY };
}

function showScreen3() {
  background('pink');
  text('3', 100, 100);

  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  fill('white');
  textSize(14);
  text('        Time, my enemy, had shut down all my doors.\n            Now, I spend time is spent in my room,\n                 dissatisfaction everywhere I turn, \n               in my own home and at work, 9 to 5.\n                           A torturous cycle.', 40,305);
}

function showScreen4() {
  background('teal');
  text('4', 100, 100);

  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(19);
  text('...',190,350);
}

function showScreen5() {
  background('pink');
  text('5', 100, 100);

  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('I need fresh air.',145,340);
}

function showScreen6() {
  background('pink');
  text('6', 100, 100);
}

function showScreen7() {
  background('pink');
  text('7', 100, 100);

  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 15, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('Despite everything I do, it’s always going\n           to be me staring back.\n         Nothing will change that.',70,50);
}

function showScreen8() {
  background('pink');
  text('8', 100, 100);

  // text box disapears
  noStroke();
  fill(0, 0, 255, 128);
  rect(-205, -405, 350, 100);
}

function showScreen9() {
  background('pink');
  text('9', 100, 100);

  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('               Whatever.\n    I’ll do the stupid affirmations.\n       It’s not like they’ll kill me.',90,320);
}

function showInstructionsCatcher() {
  background('purple');
  noStroke();
  fill(13, 156, 144, 128);
  rect(50, 50, 300, 300);

  //text 
  fill('white');
  textSize(15);
  text('  Move the catcher with the left and right \narrow keys to catch the falling affirmations.\n       Collect 20 positive affirmations.\n \n    Be careful! There are some negative\n                    affirmations.\n Collecting them will make you lose points.\nNot collecting the positive affirmations will\n            also make you lose points.\n                     Good luck!', 65, 120);

  backward.pos = { x: -100, y: -500 };
}

function playScreenAssets() {
  background(209, 237, 242);
  begin.pos = { x: -200, y: -100 };
  help.pos = { x: -500, y: -100 };
  forward.pos = { x: -300, y: -300 };
  backward.pos = { x: -400, y: -400 };

  //Create catcher 
  catcher = new Sprite(catcherImg,200, 370, 'k');
  catcher.color = color(95, 158, 160);

  //Create 1st falling object
  firstFallingObject = new Sprite(firstFallingObjectImg,120, 0,70,60);
  firstFallingObject.color = color(0, 128, 128);
  firstFallingObject.velocity.y = 2.5;
  firstFallingObject.rotationLock = true;
  firstFallingObject.textSize = 12;
  firstFallingObject.text = random(firstFallingObjectText);

  //Create 2nd falling object
  secondFallingObject = new Sprite(secondFallingObjectImg,100, 0,70,50);
  secondFallingObject.color = color(0, 128, 128);
  secondFallingObject.velocity.y = 2;
  secondFallingObject.rotationLock = true;
  secondFallingObject.textSize = 12;
  secondFallingObject.text = random(secondFallingObjectText);
}

function youWin() {
  background('pink');
  score > 19;
  catcher.x = -100;
  catcher.y = -100;

  // sets falling objects to stand still
  firstFallingObject.velocity.y = 0;
  secondFallingObject.velocity.y = 0;
  firstFallingObject.pos = { x: -700, y: -700 };
  secondFallingObject.pos = { x: -600, y: -600 };

  //draw you win text
  fill('purple');
  textSize(20);
  text('  Finished', width / 2 - 60, height / 2 - 30);
  textSize(20);
  text('A sense of peacefulness fills\n               the air.', 70, height / 2);
}

function showScreen11() {
  background('pink');
  text('11', 100, 100);

  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('  I gazed into the mirror. My reflection seemed\n                    almost proud of me.\n           I guess I did feel somewhat better.\n           Still, that shadow loomed over me.\n                   I wanted to go outside.', 40, 305);

  forward.pos = { x: forwardX, y: forwardY };
  backward.pos = { x: -100, y: -500 };
}

function showScreen12() {
  background('teal');
  text('12', 100, 100);

  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('The soft embrace of the sun consoled me.\n     This connection with peace made me\n        almost forget about my thoughts…\n                         almost.', 55, 310);

  backward.pos = { x: backwardX, y: backwardY };
}

function showScreen13() {
  background('pink');
  text('13', 100, 100);


  forward.pos = { x: 200, y: 280 };
  forward.rotation = 270;
  backward.pos = { x: -100, y: -500 };
}

function showScreen14() {
  background('teal');
  text('14', 100, 100);

  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(15);
  text("Huh? What's that?", 140, 340);

  forward.pos = { x: forwardX, y: forwardY };
  forward.rotation = 0;
  backward.pos = { x: backwardX, y: backwardY };
}

function showScreen15() {
  background('pink');
  text('15', 100, 100);
  
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('             A lone dandelion.\nDidn’t even have a chance to rebloom\n      into something so beautiful.\n  It’s untapped potential locked away.', 80, 310);

}

function showScreen16() {
  background('teal');
  text('16', 100, 100);
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('Another one..?', 145, 340);

}

function showScreen17() {
  background('pink');
  text('17', 100, 100);
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 285, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('What the...', 170, 340);
}

function showMazeIntsructions() {
  background('teal');
  text('18', 100, 100);
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(50, 50, 300, 300);

  //text
  fill('white');
  textSize(15);
  text('Following the dandelions led to a dead end.\n    But wait... Which was the way back?\n   Navigate your way out of this forest.\n         Use the arrow keys to move.\n       Find your way out of the maze.\n                    Good luck!', 65, 120);

  forward.pos = { x: 200, y: 280 };
  backward.pos = { x: -100, y: -500 };
}

function mazeScreenAssets() {
  forward.pos = { x: -100, y: -500 };
  walls = new Group();
  walls.color = color('green');
  walls.tile = 'g';
  walls.collider = 's';
  walls.w = tileSize;
  walls.h = tileSize;

  floor = new Group();
  floor.color = color('49733f');
  floor.tile = 'L';
  floor.collider = 'none';
  floor.w = tileSize;
  floor.h = tileSize;

  goal = new Group();
  goal.color = color('pink');
  goal.tile = 'h';
  goal.collider = 'none';
  goal.w = tileSize;
  goal.h = tileSize;

  tilemap = new Tiles(
    ["LLLLLLLgggLLLLLLLLLLLLLL",
      "LgggggggLggggggggggggggL",
      "LgLLLLgLLLgLgLLLLLLLgLgL",
      "LgLgLLgLLLgLgLLLLLLLLLgL",
      "LgLgLLgLLLgLgLgggggLgLgL",
      "LgLgLLLLLLgLgLgLLLgLgLgL",
      "LgLgggggLLgLgLgLgLgLgLgL",
      "LgLLLgLLLLgLgLgLgLgLgggL",
      "LggLggLggggLgLgLgLgLgLgL",
      "LgLLgLLLgLgLgLgLgLgLgLgL",
      "LgLLgggLgLLLLLgLgLgLgLhL",
      "LgLLgLgLgLgLgLgLgLgLgLhL",
      "LgLLgLgLgLgLgLgLgLgLgLgL",
      "LgLLgLgLgggLgggLgLgLgLgL",
      "LgLLgLgLLLLLLLgLgLgLLLgL",
      "LgLLgLgLgggggggLgLgggggL",
      "LgLLgLgLgLLLLLgLLLgLLLgL",
      "LgLLgLgLLLLLgLggLggLgLgL",
      "LgLLgLgLgggggLgLLLLLgLgL",
      "LgLLgLLLgLLLLLgLLLgLgLgL",
      "LgLLgggggLggLgggLggggLgL",
      "LgLLLLLLLLgLLLLLLLgLLLgL",
      "LggggggggggggggggggggggL",
      "LLLLLLLLLLLLLLLLLLLLLLLL",
    ], 15, 15, tileSize - 1, tileSize - 1);

  //Create player
  player = new Sprite(140, 30, 10);
  player.rotationLock = true;
  player.color = color('yellow');
  player.collider = 'd';

}

function youWinMaze(){
  //insert waterfall image
  background('teal');
  player.x = 700;
  player.y = -800;
  walls.x = -900;
  walls.y = -900;
  floor.x = -600;
  floor.y = -600;
  goal.x = -500;
  goal.y = -500;
  forward.pos = { x: 190, y: 280 };
  forward.rotation = 0;
  
  // draw you win text
  fill('purple');
  textSize(20);
  text('Finally,out of that forest.\n     What is this place?', width / 2 - 105, height / 2 - 30)
}

function showScreen20(){
  background('pink');
  text('20', 100, 100);
  // text box
  noStroke();
  fill(0, 0, 255, 128);
  rect(25, 285, 350, 100);

  forward.pos = { x: forwardX, y: forwardY };
}

function showScreen21(){
  background('pink');
  text('21', 100, 100);
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 15, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('        This.. was completely breathtaking.\n  I’ve never seen this before. I stared in awe,\n     and suddenly, as quickly as it vanished,\nthat feeling of self-criticism bubbled up inside me.', 50, 40);

  //remove maze assets
  player.remove();
  walls.remove();
  floor.remove();
  goal.remove();

  //remove collection game assets
  firstFallingObject.remove();
  secondFallingObject.remove();
  

  forward.pos = { x: forwardX, y: forwardY };
  backward.pos = { x: -100, y: -500 };
}

function showScreen22(){
  background('teal');
  text('22', 100, 100);
  
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 15, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('My vision blurred, tears streamed down my face.\n          I was a disappoint to everyone.\n              I’d become no one in life,\n   and now it was too late for that to change.', 50, 40);
  

  forward.pos = { x: forwardX, y: forwardY };
  backward.pos = {x: backwardX, y: backwardY};
}

function showScreen23(){
  background('black');
  text('23', 100, 100);
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 15, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('      With my eyes closed,\nI wiped the tears that had fallen.\nWas this what I was destined for?\n              Nothing?', 100, 40);
}

function showScreen24(){
  background('pink');
  text('24', 100, 100);
  
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 15, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('  Something tickled my hand.\n          I open my eyes.\n     I was being swarmed by\n            dandelions..?', 100, 40);
}

function showScreen25(){
  background('teal');
  text('25', 100, 100);
  
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 15, 350, 100);

  //text
  fill('white');
  textSize(15);
  text(' I heard small voices\nemanating from them.', 125, 60);

  //floating text
  fill('white');
  textSize(15);
  text("It's okay",50,250);
  text("Don't Cry!",200,230);
  text("There's still a chance to rebloom!",40,180);
  text("There's still hope",30,330);
  text("Don't give up",170,270);
  text("You're stronger than you think",70,380);
  text("You're more than you know",170,320);
  text("Look within",280,290);
  textSize(5);
  text("Riley it okay\nIm joy!", 350,370);
}

function showScreen26(){
  background('pink');
  text('26', 100, 100);
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 15, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('    Words came at me from every corner.\nYet, I could still here each one crystal clear.\n                  I could change.\n            I reflected upon my day,', 60, 40);

  //floating text
  fill('white');
  textSize(15);
  text("It's okay",50,250);
  text("Don't Cry!",200,230);
  text("There's still a chance to rebloom!",40,180);
  text("There's still hope",30,330);
  text("Don't give up",170,270);
  text("You're stronger than you think",70,380);
  text("You're more than you know",170,320);
  text("Look within",280,290);
  textSize(5);
  text("Riley it okay\nIm joy!", 350,370);

}

function showScreen27(){
  background('pink');
  text('27', 100, 100);
  // text box
  noStroke();
  fill(13, 156, 144, 128);
  rect(25, 15, 350, 100);

  //text
  fill('white');
  textSize(15);
  text('I’m just like a dandelion waiting to rebloom.\n I just needed to head towards that change.\n            For once, I was hopeful.', 60, 50);

  backward.pos = { x: -100, y: -500 };
  
}

function showScreen28(){
  background('teal');
  text('The End', 100, 100);

  forward.pos = { x: -100, y: -700 };
}